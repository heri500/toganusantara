ALTER TABLE `detailpembelian` ADD `iddetail` BIGINT NOT NULL AUTO_INCREMENT FIRST, ADD PRIMARY KEY (`iddetail`);
