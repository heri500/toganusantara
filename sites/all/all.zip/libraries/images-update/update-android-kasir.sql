ALTER TABLE `penjualan` ADD `android_order` TINYINT NOT NULL DEFAULT '0' AFTER `changed`;
